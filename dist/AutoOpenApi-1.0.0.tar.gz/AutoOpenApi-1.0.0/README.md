# AutoOpenApi

make change

Update version in setup.cfg


# WINDOWS
py -m build : build command

py -m twine upload --repository pypi dist/*

# UBUNTU

python3 -m build

python3 -m twine upload --repository pypi dist/*

